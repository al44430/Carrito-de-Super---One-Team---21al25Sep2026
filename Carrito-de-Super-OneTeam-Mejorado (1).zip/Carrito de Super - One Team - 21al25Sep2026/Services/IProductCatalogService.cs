using Carrito_de_Super___One_Team___21al25Sep2026.Models;

namespace Carrito_de_Super___One_Team___21al25Sep2026.Services
{
    // Abstrae de dónde viene el catálogo (hoy: lista fija; mañana: base de datos)
    public interface IProductCatalogService
    {
        List<Producto> ObtenerCatalogo();
        List<string> ObtenerCategorias();
        Producto? BuscarPorSku(string sku);
        ConfiguracionEstilo ObtenerEstilos();
    }
}
