using System.Text.Json;
using Carrito_de_Super___One_Team___21al25Sep2026.Models;

namespace Carrito_de_Super___One_Team___21al25Sep2026.Services
{
    // Guarda el carrito en la sesión del servidor (así sobrevive a recargas de página).
    public class SessionCartService : ICartService
    {
        private const string SessionKeyCarrito = "CarritoCompras";
        private readonly IHttpContextAccessor _httpContextAccessor;

        public SessionCartService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        private ISession Session =>
            _httpContextAccessor.HttpContext?.Session
            ?? throw new InvalidOperationException("No hay una sesión HTTP disponible.");

        public List<ItemCarrito> ObtenerCarrito()
        {
            var carritoJson = Session.GetString(SessionKeyCarrito);
            if (string.IsNullOrEmpty(carritoJson))
            {
                return new List<ItemCarrito>();
            }

            return JsonSerializer.Deserialize<List<ItemCarrito>>(carritoJson) ?? new List<ItemCarrito>();
        }

        private void Guardar(List<ItemCarrito> carrito)
        {
            Session.SetString(SessionKeyCarrito, JsonSerializer.Serialize(carrito));
        }

        public void AgregarProducto(Producto producto)
        {
            var carrito = ObtenerCarrito();
            var item = carrito.FirstOrDefault(i => i.Producto.Sku == producto.Sku);

            if (item != null)
            {
                item.Cantidad++;
            }
            else
            {
                carrito.Add(new ItemCarrito { Producto = producto, Cantidad = 1 });
            }

            Guardar(carrito);
        }

        public void IncrementarCantidad(string sku)
        {
            var carrito = ObtenerCarrito();
            var item = carrito.FirstOrDefault(i => i.Producto.Sku == sku);
            if (item == null) return;

            item.Cantidad++;
            Guardar(carrito);
        }

        public void DecrementarCantidad(string sku)
        {
            var carrito = ObtenerCarrito();
            var item = carrito.FirstOrDefault(i => i.Producto.Sku == sku);
            if (item == null) return;

            item.Cantidad--;

            // Validación: nunca dejar cantidades en 0 o negativas dentro del carrito.
            // Si llega a 0, el producto se quita por completo.
            if (item.Cantidad <= 0)
            {
                carrito.Remove(item);
            }

            Guardar(carrito);
        }

        public void EliminarProducto(string sku)
        {
            var carrito = ObtenerCarrito();
            carrito.RemoveAll(i => i.Producto.Sku == sku);
            Guardar(carrito);
        }

        public void VaciarCarrito()
        {
            Session.Remove(SessionKeyCarrito);
        }

        public decimal ObtenerTotal() => ObtenerCarrito().Sum(i => i.Subtotal);

        public int ObtenerTotalArticulos() => ObtenerCarrito().Sum(i => i.Cantidad);
    }
}
