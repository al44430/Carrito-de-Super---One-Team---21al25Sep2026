using Carrito_de_Super___One_Team___21al25Sep2026.Models;

namespace Carrito_de_Super___One_Team___21al25Sep2026.Services
{
    // Catálogo de productos "duro" en memoria.
    // Si en el futuro se agrega base de datos, solo hay que reemplazar esta clase
    // (la interfaz IProductCatalogService no cambia, así que el resto de la app no se toca).
    public class ProductCatalogService : IProductCatalogService
    {
        private readonly List<Producto> _catalogo;
        private readonly ConfiguracionEstilo _estilos;

        public ProductCatalogService()
        {
            // Paleta "mercado fresco": verde pino para marca/confianza + naranja tostado
            // como acento de compra (precios, botones). Cambia estos valores y toda
            // la interfaz se actualiza sola.
            _estilos = new ConfiguracionEstilo
            {
                ColorFondo = "#F5F6F1",
                ColorSuperficie = "#FFFFFF",
                ColorSuperficieSuave = "#EEF1EA",
                ColorLinea = "#E3E4DA",

                ColorPrimario = "#16342C",
                ColorPrimarioSuave = "#E7EDE9",

                ColorAcento = "#E8542A",
                ColorAcentoSuave = "#FCE4DA",
                ColorTextoBotones = "#FFFFFF",

                ColorTexto = "#1B2420",
                ColorTextoSuave = "#6E7970",

                ColorExito = "#1F7A4D",
                ColorExitoSuave = "#DFF3E7",

                FuenteDisplay = "'Fraunces', Georgia, serif",
                FuenteBase = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
            };

            // CATALOGO DE ARTÍCULOS PARAMETRIZADO
            // Agrega o remueve elementos aquí y la interfaz se adaptará automáticamente
            _catalogo = new List<Producto>
            {
                new Producto { Sku = "7500761400", Nombre = "Coca-Cola Original 600 ml",        Precio = 21.00m, ImagenUrl = "/images/7500761400.jpg", Categoria = "Bebidas" },
                new Producto { Sku = "0417890019", Nombre = "Sopa Maruchan de Camarón 64g",     Precio = 19.00m, ImagenUrl = "/images/0417890019.jpg", Categoria = "Snacks"  },
                new Producto { Sku = "1011101456", Nombre = "Sabritas Sal Original",            Precio = 27.00m, ImagenUrl = "/images/1011101456.jpg", Categoria = "Botanas" },
                new Producto { Sku = "1011167612", Nombre = "Doritos Nacho 75g",                Precio = 26.00m, ImagenUrl = "/images/1011167612.jpg", Categoria = "Botanas" },
                new Producto { Sku = "2111624529", Nombre = "Café Americano Mediano 360 ml",    Precio = 24.00m, ImagenUrl = "/images/2111624529.jpg", Categoria = "Bebidas" },
                new Producto { Sku = "8104100422", Nombre = "Agua Purificada Bonafont 1 Litro", Precio = 16.50m, ImagenUrl = "/images/8104100422.jpg", Categoria = "Bebidas" }
            };
        }

        public List<Producto> ObtenerCatalogo() => _catalogo;

        public List<string> ObtenerCategorias() =>
            _catalogo.Select(p => p.Categoria).Distinct().OrderBy(c => c).ToList();

        public Producto? BuscarPorSku(string sku) =>
            _catalogo.FirstOrDefault(p => p.Sku == sku);

        public ConfiguracionEstilo ObtenerEstilos() => _estilos;
    }
}
