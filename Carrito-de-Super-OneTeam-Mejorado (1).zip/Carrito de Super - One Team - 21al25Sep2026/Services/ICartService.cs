using Carrito_de_Super___One_Team___21al25Sep2026.Models;

namespace Carrito_de_Super___One_Team___21al25Sep2026.Services
{
    // Toda la lógica del carrito vive aquí, no en el PageModel.
    // Esto lo hace reutilizable (por ejemplo desde otra página) y fácil de probar.
    public interface ICartService
    {
        List<ItemCarrito> ObtenerCarrito();
        void AgregarProducto(Producto producto);
        void IncrementarCantidad(string sku);
        void DecrementarCantidad(string sku);
        void EliminarProducto(string sku);
        void VaciarCarrito();
        decimal ObtenerTotal();
        int ObtenerTotalArticulos();
    }
}
