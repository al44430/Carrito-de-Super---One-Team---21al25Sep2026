using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Carrito_de_Super___One_Team___21al25Sep2026.Models;
using Carrito_de_Super___One_Team___21al25Sep2026.Services;

namespace Carrito_de_Super___One_Team___21al25Sep2026.Pages
{
    // ==========================================
    // MODELO DE LA PÁGINA (CONTROLADOR/LÓGICA)
    // La lógica de negocio real vive en los servicios inyectados (ICartService,
    // IProductCatalogService); este PageModel solo coordina la vista con ellos.
    // ==========================================
    public class IndexModel : PageModel
    {
        private readonly ICartService _cartService;
        private readonly IProductCatalogService _catalogoService;

        public IndexModel(ICartService cartService, IProductCatalogService catalogoService)
        {
            _cartService = cartService;
            _catalogoService = catalogoService;
        }

        // Propiedades expuestas a la vista (Index.cshtml)
        public List<Producto> CatalogoProductos { get; set; } = new List<Producto>();
        public List<string> Categorias { get; set; } = new List<string>();
        public List<ItemCarrito> Carrito { get; set; } = new List<ItemCarrito>();
        public ConfiguracionEstilo Estilos { get; set; } = new ConfiguracionEstilo();

        public decimal TotalAPagar => Carrito.Sum(item => item.Subtotal);
        public int TotalArticulos => Carrito.Sum(item => item.Cantidad);

        // Mensaje de confirmación que se muestra como "toast" tras una acción (Post-Redirect-Get)
        [TempData]
        public string? Mensaje { get; set; }

        public void OnGet()
        {
            CargarDatos();
        }

        public IActionResult OnPostAgregarAlCarrito(string sku)
        {
            var producto = _catalogoService.BuscarPorSku(sku);
            if (producto != null)
            {
                _cartService.AgregarProducto(producto);
                Mensaje = $"{producto.Nombre} se añadió al carrito.";
            }

            return RedirectToPage();
        }

        public IActionResult OnPostIncrementar(string sku)
        {
            _cartService.IncrementarCantidad(sku);
            return RedirectToPage();
        }

        public IActionResult OnPostDecrementar(string sku)
        {
            _cartService.DecrementarCantidad(sku);
            return RedirectToPage();
        }

        public IActionResult OnPostEliminar(string sku)
        {
            _cartService.EliminarProducto(sku);
            Mensaje = "Producto eliminado del carrito.";
            return RedirectToPage();
        }

        public IActionResult OnPostVaciarCarrito()
        {
            _cartService.VaciarCarrito();
            Mensaje = "El carrito se vació.";
            return RedirectToPage();
        }

        public IActionResult OnPostFinalizarCompra()
        {
            var totalArticulos = _cartService.ObtenerTotalArticulos();

            if (totalArticulos == 0)
            {
                Mensaje = "Agrega productos antes de finalizar la compra.";
                return RedirectToPage();
            }

            // Simulación de checkout: en un proyecto real aquí se generaría un pedido/orden.
            var total = _cartService.ObtenerTotal();
            _cartService.VaciarCarrito();
            Mensaje = $"¡Compra realizada! Total pagado: ${total:F2}";

            return RedirectToPage();
        }

        private void CargarDatos()
        {
            Estilos = _catalogoService.ObtenerEstilos();
            CatalogoProductos = _catalogoService.ObtenerCatalogo();
            Categorias = _catalogoService.ObtenerCategorias();
            Carrito = _cartService.ObtenerCarrito();
        }
    }
}
