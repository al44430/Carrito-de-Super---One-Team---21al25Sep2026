namespace Carrito_de_Super___One_Team___21al25Sep2026.Models
{
    // Representa un producto del catálogo
    public class Producto
    {
        public string Sku { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
        public string ImagenUrl { get; set; } = string.Empty; // Ruta o placeholder de la imagen
        public string Categoria { get; set; } = "General";
    }
}
