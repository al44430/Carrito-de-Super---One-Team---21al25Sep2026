namespace Carrito_de_Super___One_Team___21al25Sep2026.Models
{
    // Configuración estilística parametrizada de la tienda (sistema de tokens de diseño).
    // Cambia estos valores y toda la interfaz se actualiza, sin tocar el HTML/CSS.
    public class ConfiguracionEstilo
    {
        // Fondo y superficies
        public string ColorFondo { get; set; } = "#F5F6F1";
        public string ColorSuperficie { get; set; } = "#FFFFFF";
        public string ColorSuperficieSuave { get; set; } = "#EEF1EA";
        public string ColorLinea { get; set; } = "#E3E4DA";

        // Marca (header, textos destacados)
        public string ColorPrimario { get; set; } = "#16342C";
        public string ColorPrimarioSuave { get; set; } = "#E7EDE9";

        // Acento: botones de acción, precios, elementos interactivos
        public string ColorAcento { get; set; } = "#E8542A";
        public string ColorAcentoSuave { get; set; } = "#FCE4DA";
        public string ColorTextoBotones { get; set; } = "#FFFFFF";

        // Texto
        public string ColorTexto { get; set; } = "#1B2420";
        public string ColorTextoSuave { get; set; } = "#6E7970";

        // Estados
        public string ColorExito { get; set; } = "#1F7A4D";
        public string ColorExitoSuave { get; set; } = "#DFF3E7";

        // Tipografía
        public string FuenteDisplay { get; set; } = "'Fraunces', Georgia, serif";
        public string FuenteBase { get; set; } = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
    }
}
