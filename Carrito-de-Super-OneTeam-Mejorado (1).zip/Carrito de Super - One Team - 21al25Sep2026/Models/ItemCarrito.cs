namespace Carrito_de_Super___One_Team___21al25Sep2026.Models
{
    // Representa un elemento dentro del carrito de compras
    public class ItemCarrito
    {
        public Producto Producto { get; set; } = new Producto();
        public int Cantidad { get; set; }
        public decimal Subtotal => Producto.Precio * Cantidad;
    }
}
